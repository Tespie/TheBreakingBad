export const Strings = {
    THEBREAK:'The Breaking bad',
    

};