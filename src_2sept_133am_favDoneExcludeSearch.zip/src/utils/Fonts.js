export const Fonts = {
    FONT_BOLD: 'Roboto-Bold',
    FONT_REGULAR: 'Roboto-Regular',
    FONT_LIGHT: 'Roboto-Light',
    FONT_ITALIC: 'OpenSans-Italic',
    
};