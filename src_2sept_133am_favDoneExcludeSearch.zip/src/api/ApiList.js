export const ApiList = {
    // end points
    CHARACTERS: "characters",


}